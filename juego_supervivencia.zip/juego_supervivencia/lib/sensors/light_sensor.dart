import 'package:light/light.dart';
import 'dart:async';

class LightSensor {
  late Light _light;
  late StreamSubscription _lightSubscription;

  Future<void> initPlatformState(Function(int) onData) async {
    _light = Light();
    try {
      _lightSubscription = _light.lightSensorStream.listen(onData);
    } on Exception catch (e) {
      print(e);
    }
  }

  void dispose() {
    _lightSubscription.cancel();
  }
}