import 'dart:async';
import 'dart:math';

class GameLogic {
  List<List<bool>> _maze = [];
  double _playerX = 0.0;
  double _playerY = 0.0;
  double _monsterX = 0.0;
  double _monsterY = 0.0;
  bool _isGameOver = false;
  bool _isUsingFlashlight = false;
  int _remainingTime = 60;
  double _batteryLevel = 100.0;
  String? _gameOverMessage;
  List<Point<int>> _batteries = [];
  Point<int> _exit = Point(9, 9);

  Timer? _gameTimer;
  Timer? _monsterMovementTimer;
  Timer? _batteryDrainTimer;

  String _luxString = 'Desconocido';
  String get luxString => _luxString;
  bool get isGameOver => _isGameOver;
  bool get isUsingFlashlight => _isUsingFlashlight;
  int get remainingTime => _remainingTime;
  double get batteryLevel => _batteryLevel;
  String? get gameOverMessage => _gameOverMessage;
  List<List<bool>> get maze => _maze;
  double get playerX => _playerX;
  double get playerY => _playerY;
  double get monsterX => _monsterX;
  double get monsterY => _monsterY;
  List<Point<int>> get batteries => _batteries;
  Point<int> get exit => _exit;

  GameLogic() {
    _generateMaze();
    _placeBatteries();
    _placeMonster();
  }

  void startGame(Function setState, Function onGameOver) {
    _resetGame();
    _startGameTimer(setState, onGameOver);
    _startMonsterMovement(setState, onGameOver);
  }

  void _resetGame() {
    _isGameOver = false;
    _playerX = 0.0;
    _playerY = 0.0;
    _luxString = 'Desconocido';
    _remainingTime = 60;
    _batteryLevel = 100.0;
    _isUsingFlashlight = false;
    _gameOverMessage = null;
    _generateMaze();
    _placeBatteries();
    _placeMonster();
  }

  void updateGameState(int luxValue) {
    if (_isGameOver) return;
    
    _luxString = "$luxValue";
    if (_isUsingFlashlight) {
      luxValue += 300;
    }
  }

  void updatePlayerPosition(double dx, double dy, Function onGameOver) {
    if (_isGameOver) return;
    if (_isValidMove(_playerX + dx, _playerY)) {
      _playerX += dx;
    }
    if (_isValidMove(_playerX, _playerY + dy)) {
      _playerY += dy;
    }
    _checkBatteryPickup();
    _checkMonsterCollision(onGameOver);
    _checkExit(onGameOver);
  }

  bool _isValidMove(double x, double y) {
    int cellX = x.round();
    int cellY = y.round();
    return cellX >= 0 && cellX < 10 && cellY >= 0 && cellY < 10 && !_maze[cellY][cellX];
  }

  void _checkBatteryPickup() {
    _batteries.removeWhere((battery) {
      if ((battery.x - _playerX.round()).abs() < 0.5 && (battery.y - _playerY.round()).abs() < 0.5) {
        _batteryLevel = min(_batteryLevel + 20, 100);
        return true;
      }
      return false;
    });
  }

  void _checkMonsterCollision(Function onGameOver) {
    if ((_monsterX - _playerX).abs() < 0.5 && (_monsterY - _playerY).abs() < 0.5) {
      _gameOver("El monstruo te ha atrapado!", onGameOver);
    }
  }

  void _checkExit(Function onGameOver) {
    if ((_exit.x - _playerX.round()).abs() < 0.5 && (_exit.y - _playerY.round()).abs() < 0.5) {
      _gameOver("Escapaste del laberinto!", onGameOver);
    }
  }

  void _generateMaze() {
    _maze = List.generate(10, (_) => List.filled(10, false));
    for (int i = 0; i < 20; i++) {
      int x = Random().nextInt(10);
      int y = Random().nextInt(10);
      _maze[y][x] = true;
    }
    _maze[0][0] = false;
    _maze[_exit.y][_exit.x] = false;
  }

  void _placeBatteries() {
    _batteries.clear();
    for (int i = 0; i < 3; i++) {
      int x, y;
      do {
        x = Random().nextInt(10);
        y = Random().nextInt(10);
      } while (_maze[y][x] || (x == _exit.x && y == _exit.y));
      _batteries.add(Point(x, y));
    }
  }

  void _placeMonster() {
    do {
      _monsterX = Random().nextInt(10).toDouble();
      _monsterY = Random().nextInt(10).toDouble();
    } while (_maze[_monsterY.round()][_monsterX.round()] || 
             (_monsterX.round() == _exit.x && _monsterY.round() == _exit.y));
  }

  void _startGameTimer(Function setState, Function onGameOver) {
    _gameTimer?.cancel();
    _gameTimer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_isGameOver) {
        timer.cancel();
        return;
      }
      if (_remainingTime > 0) {
        _remainingTime--;
        setState();
      }
      if (_remainingTime == 0) {
        _gameOver("El tiempo ha terminado! No lograste escapar.", onGameOver);
      }
    });
  }

  void _startMonsterMovement(Function setState, Function onGameOver) {
    _monsterMovementTimer?.cancel();
    _monsterMovementTimer = Timer.periodic(Duration(milliseconds: 500), (timer) {
      if (_isGameOver) {
        timer.cancel();
        return;
      }
      _moveMonster(onGameOver);
      setState();
    });
  }

  void _moveMonster(Function onGameOver) {
    double speed = _luxString == 'Desconocido' ? 0.1 : int.parse(_luxString) < 40 ? 0.5 : 0.3;
    if (_isUsingFlashlight) {
      speed *= 0.5;
    }
    double dx = _playerX - _monsterX;
    double dy = _playerY - _monsterY;
    double distance = sqrt(dx * dx + dy * dy);
    if (distance > 0) {
      double newX = _monsterX + (dx / distance) * speed;
      double newY = _monsterY + (dy / distance) * speed;
      if (_isValidMove(newX, newY)) {
        _monsterX = newX;
        _monsterY = newY;
      } else {
        _attemptRandomMove();
      }
      _checkMonsterCollision(onGameOver);
    }
  }

  void _attemptRandomMove() {
    List<Point<double>> possibleMoves = [
      Point(_monsterX + 1.0, _monsterY),
      Point(_monsterX - 1.0, _monsterY),
      Point(_monsterX, _monsterY + 1.0),
      Point(_monsterX, _monsterY - 1.0),
    ];
    possibleMoves.shuffle();
    for (var move in possibleMoves) {
      if (_isValidMove(move.x, move.y)) {
        _monsterX = move.x;
        _monsterY = move.y;
        break;
      }
    }
  }

  void toggleFlashlight() {
    if (_batteryLevel > 0) {
      _isUsingFlashlight = !_isUsingFlashlight;
      if (_isUsingFlashlight) {
        _batteryDrainTimer = Timer.periodic(Duration(seconds: 1), (timer) {
          _batteryLevel -= 5;
          if (_batteryLevel <= 0) {
            _batteryLevel = 0;
            _isUsingFlashlight = false;
            timer.cancel();
          }
        });
      } else {
        _batteryDrainTimer?.cancel();
      }
    }
  }

  void _gameOver(String message, Function onGameOver) {
    if (_isGameOver) return;
    _isGameOver = true;
    _gameOverMessage = message;
    _stopAllTimers();
    onGameOver();
  }

  void _stopAllTimers() {
    _gameTimer?.cancel();
    _monsterMovementTimer?.cancel();
    _batteryDrainTimer?.cancel();
  }

  void dispose() {
    _stopAllTimers();
  }
}