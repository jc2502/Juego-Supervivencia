import 'package:flutter/material.dart';
import '../logics/game_logic.dart';

class MazePainter extends CustomPainter {
  final GameLogic gameLogic;

  MazePainter(this.gameLogic);

  @override
  void paint(Canvas canvas, Size size) {
    final cellSize = size.width / 10;
    final paint = Paint();

    for (int y = 0; y < 10; y++) {
      for (int x = 0; x < 10; x++) {
        if (gameLogic.maze[y][x]) {
          paint.color = Colors.black;
          canvas.drawRect(
            Rect.fromLTWH(x * cellSize, y * cellSize, cellSize, cellSize),
            paint,
          );
        }
      }
    }

    paint.color = Colors.green;
    canvas.drawRect(
      Rect.fromLTWH(gameLogic.exit.x * cellSize, gameLogic.exit.y * cellSize, cellSize, cellSize),
      paint,
    );

    _drawEmoji(canvas, '🧍', gameLogic.playerX, gameLogic.playerY, cellSize);

    _drawEmoji(canvas, '👹', gameLogic.monsterX, gameLogic.monsterY, cellSize);

    for (var battery in gameLogic.batteries) {
      _drawEmoji(canvas, '⚡', battery.x.toDouble(), battery.y.toDouble(), cellSize);
    }

    if (gameLogic.isUsingFlashlight) {
      final flashlightPaint = Paint()
        ..color = Colors.yellow.withOpacity(0.3)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(
        Offset(gameLogic.playerX * cellSize + cellSize / 2, gameLogic.playerY * cellSize + cellSize / 2),
        cellSize * 3,
        flashlightPaint,
      );
    }
  }

  void _drawEmoji(Canvas canvas, String emoji, double x, double y, double cellSize) {
    final textPainter = TextPainter(
      text: TextSpan(
        text: emoji,
        style: TextStyle(fontSize: cellSize * 0.8),
      ),
      textDirection: TextDirection.ltr,
    );
    textPainter.layout();
    textPainter.paint(
      canvas,
      Offset(x * cellSize + (cellSize - textPainter.width) / 2,
             y * cellSize + (cellSize - textPainter.height) / 2),
    );
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => true;
}