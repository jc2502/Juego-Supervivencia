import 'package:flutter/material.dart';
import 'package:sensors_plus/sensors_plus.dart';
import '../logics/game_logic.dart';
import '../sensors/light_sensor.dart';
import '../painters/maze_painter.dart';

class GameScreen extends StatefulWidget {
  @override
  _GameScreenState createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  late GameLogic _gameLogic;
  late LightSensor _lightSensor;
  bool _isDialogShowing = false;

  @override
  void initState() {
    super.initState();
    _gameLogic = GameLogic();
    _lightSensor = LightSensor();
    _initGame();
    _initAccelerometer();
  }

  void _initGame() {
    _lightSensor.initPlatformState(onLightData);
    _gameLogic.startGame(() => setState(() {}), _onGameOver);
    _isDialogShowing = false;
  }

  void _initAccelerometer() {
    accelerometerEvents.listen((AccelerometerEvent event) {
      if (!_gameLogic.isGameOver) {
        double x = event.x;
        double y = event.y;
        double movementThreshold = 4;
        double movementSpeed = 1;
        if (x.abs() > movementThreshold  || y.abs() > movementThreshold ) {
          setState(() {
            if (x > movementThreshold) {
              _gameLogic.updatePlayerPosition(-movementSpeed, 0.0, _onGameOver);
            } else if (x < -movementThreshold) {
              _gameLogic.updatePlayerPosition(movementSpeed, 0.0, _onGameOver);
            }
            if (y > movementThreshold) {
              _gameLogic.updatePlayerPosition(0.0, movementSpeed, _onGameOver);
            } else if (y < -movementThreshold) {
              _gameLogic.updatePlayerPosition(0.0, -movementSpeed, _onGameOver);
            }
          });
        }
      }
    });
  }

  void onLightData(int luxValue) {
    if (!_gameLogic.isGameOver) {
      _gameLogic.updateGameState(luxValue);
      setState(() {});
    }
  }

  void _onGameOver() {
    if (!_isDialogShowing) {
      _isDialogShowing = true;
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: Color(0xFF4A4A4A),
            title: Text(
              _gameLogic.gameOverMessage!.contains('Escapaste') ? '¡Victoria!' : 'Game Over',
              style: TextStyle(color: Colors.white),
            ),
            content: Text(
              _gameLogic.gameOverMessage!,
              style: TextStyle(color: Colors.white),
            ),
            actions: <Widget>[
              TextButton(
                child: Text('Jugar de nuevo', style: TextStyle(color: Colors.white)),
                onPressed: () {
                  Navigator.of(context).pop();
                  setState(() {
                    _initGame();
                  });
                },
              ),
            ],
          );
        },
      ).then((_) {
        _isDialogShowing = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Escapa del laberinto', style: TextStyle(color: Colors.white)),
        backgroundColor: Color.fromARGB(255, 38, 54, 35),
      ),
      body: Container(
        color: Color(0xFF4A4A4A),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text('Nivel de luz: ${_gameLogic.luxString} lux', style: TextStyle(color: Colors.white)),
              Text('Batería: ${_gameLogic.batteryLevel.toStringAsFixed(0)}%', style: TextStyle(color: Colors.white)),
              Text('Tiempo restante: ${_gameLogic.remainingTime} segundos', style: TextStyle(color: Colors.white)),
              SizedBox(height: 20),
              Container(
                width: 300,
                height: 300,
                child: CustomPaint(
                  painter: MazePainter(_gameLogic),
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color.fromARGB(255, 38, 54, 35),
                ),
                onPressed: () {
                  setState(() {
                    _gameLogic.toggleFlashlight();
                  });
                },
                child: Text(
                  _gameLogic.isUsingFlashlight ? 'Apagar linterna' : 'Encender linterna',
                  style: TextStyle(color: Colors.white),
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color.fromARGB(255, 38, 54, 35),
                ),
                onPressed: () {
                  setState(() {
                    _initGame();
                  });
                },
                child: Text(
                  'Reiniciar juego',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _gameLogic.dispose();
    _lightSensor.dispose();
    super.dispose();
  }
}
