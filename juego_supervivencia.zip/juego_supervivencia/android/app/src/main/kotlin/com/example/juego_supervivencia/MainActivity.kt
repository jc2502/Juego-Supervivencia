package com.example.juego_supervivencia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
